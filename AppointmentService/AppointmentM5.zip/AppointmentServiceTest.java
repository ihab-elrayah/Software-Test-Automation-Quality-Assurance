import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment validAppointment;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        validAppointment = new Appointment("ID123", new Date(System.currentTimeMillis() + 100000), "Test appointment");
    }

    @Test
    public void testAddValidAppointment() {
        service.addAppointment(validAppointment);
        assertNotNull(service.getAppointment("ID123"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        service.addAppointment(validAppointment);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(validAppointment);
        });
    }

    @Test
    public void testDeleteValidAppointment() {
        service.addAppointment(validAppointment);
        service.deleteAppointment("ID123");
        assertNull(service.getAppointment("ID123"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("IDXYZ");
        });
    }
}
