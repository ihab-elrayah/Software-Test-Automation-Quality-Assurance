import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Appointment appointment = new Appointment("ID123", new Date(System.currentTimeMillis() + 100000), "Test appointment");
        assertNotNull(appointment);
    }

    @Test
    public void testInvalidAppointmentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, new Date(), "Test appointment");
        });
    }

    @Test
    public void testInvalidAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ID123", new Date(System.currentTimeMillis() - 100000), "Test appointment");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ID123", new Date(), null);
        });
    }
}
