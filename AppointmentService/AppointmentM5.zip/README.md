Appointment.java:
Represents individual appointments with unique ID, date, and description.
Ensures the appointment ID is unique, the date is not in the past, and description is valid.
Uses java.util.Date for managing the date.


AppointmentService.java:
Manages a collection of appointments using in-memory data structures.
Provides methods to add, retrieve, and delete appointments by their unique ID.


AppointmentTest.java:
Contains unit tests for the Appointment class.
Ensures that all appointment attributes are valid and meet requirements.


AppointmentServiceTest.java:
Contains unit tests for the AppointmentService class.
Tests the functionalities of adding and deleting appointments.