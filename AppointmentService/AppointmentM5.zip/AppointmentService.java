import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private Map<String, Appointment> appointmentMap = new HashMap<>(); // Use a map for constant-time lookup by appointmentId

    public void addAppointment(Appointment appointment) {
        if (appointmentMap.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }
        appointmentMap.put(appointment.getAppointmentId(), appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (!appointmentMap.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        appointmentMap.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        return appointmentMap.get(appointmentId);
    }
}