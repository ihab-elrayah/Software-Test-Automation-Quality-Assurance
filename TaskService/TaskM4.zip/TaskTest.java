import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("1", "Test Task", "This is a test task.");
        assertEquals("1", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task.", task.getDescription());
    }

    @Test
    public void testInvalidTaskIdCreation() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Valid Name", "Valid Description");
        });
    }

    @Test
    public void testInvalidTaskNameCreation() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", null, "Valid Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "This name is definitely way too long to be valid.", "Valid Description");
        });
    }

    @Test
    public void testInvalidTaskDescriptionCreation() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Valid Name", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Valid Name", "This description is certainly way too long to be considered valid because it exceeds the maximum allowed length.");
        });
    }
}
