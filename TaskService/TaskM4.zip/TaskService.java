import java.util.*;

public class TaskService {

        // A map to store tasks with their Task ID as the key for quick retrieval.
    private Map<String, Task> taskMap = new HashMap<>(); // Use a map for constant-time lookup by taskId

    //Adds a new task to the service. 
    public void addTask(Task task) {
        if (taskMap.containsKey(task.getTaskId())) {     //task The task to be added.
            throw new IllegalArgumentException("Task ID already exists."); //throws IllegalArgumentException if a task with the same ID already exists.

        }
        taskMap.put(task.getTaskId(), task);
    }

    // Deletes a task from the service using its Task ID.
    public void deleteTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.remove(taskId);
    }

    // Updates the name of a task using its Task ID.
    public void updateTaskName(String taskId, String newName) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.get(taskId).setName(newName);
    }

    // Updates the description of a task using its Task ID.
    public void updateTaskDescription(String taskId, String newDescription) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.get(taskId).setDescription(newDescription);
    }

    // Retrieves a task from the service using its Task ID.
    public Task getTask(String taskId) {
        return taskMap.get(taskId);
    }
}
