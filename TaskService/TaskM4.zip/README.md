Task.java:
Represents a single task.
Each task has a unique ID, name, and description.
The task ID is immutable, but the name and description can be updated.


TaskService.java:
Manages a collection of tasks in memory.
Supports operations to add, delete, and update tasks using their IDs.


TaskTest.java:
Contains JUnit tests for the Task class.
Validates the correctness of task creation and properties.


TaskServiceTest.java:
Contains JUnit tests for the TaskService class.
Validates task management operations like add, delete, and update.