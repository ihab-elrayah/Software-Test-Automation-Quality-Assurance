import org.junit.Test;
import static org.junit.Assert.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
    }

    @Test
    public void testDeleteContact() {
    }

}
