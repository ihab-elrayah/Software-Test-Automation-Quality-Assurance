import org.junit.Test;


public class ContactTest {

    @Test
    public void testContactCreation() {
    }

}

