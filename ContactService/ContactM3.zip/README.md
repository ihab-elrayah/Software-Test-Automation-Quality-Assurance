Contact.java:
Represents an individual contact.
Each contact has a unique ID, firstName, lastName, phone number and address.
The ID is fixed, but the other details can be modified.


ContactService.java:
Manages a collection of contacts in memory.
Supports operations to add, delete, and update contacts based on their IDs.


ContactTest.java:
Contains JUnit tests for the Contact class.
Checks the correctness of contact creation and its properties.


ContactServiceTest.java:
Contains JUnit tests for the ContactService class.
Validates contact management operations like add, delete, and update.