import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if(contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactID(), contact);
    }

    public void deleteContact(String contactID) {
        if(!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contacts.remove(contactID);
    }

    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }

    public void updateFirstName(String contactID, String newFirstName) {
        Contact contact = getContact(contactID);
        if(contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }
        contact.setFirstName(newFirstName);
    }

    public void updateLastName(String contactID, String newLastName) {
        Contact contact = getContact(contactID);
        if(contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }
        contact.setLastName(newLastName);
    }

    public void updatePhone(String contactID, String newPhone) {
        Contact contact = getContact(contactID);
        if(contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }
        contact.setPhone(newPhone);
    }

    public void updateAddress(String contactID, String newAddress) {
        Contact contact = getContact(contactID);
        if(contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }
        contact.setAddress(newAddress);
    }
}
